The 3 Tesla version of the atlas is provided as a standalone atlas of the [subcortex](/Group-Parcellation/3T/Subcortex-Only/) and incorporated into existing cortex-only atlases to yield [cortex-subcortex](/Group-Parcellation/3T/Cortex-Subcortex/) atlases.  


![alt test](/images/3T.jpg)
